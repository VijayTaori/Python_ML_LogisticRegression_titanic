

```python
# Python 3.7
# Using famous Titanic data to predict the people who survived or did not survive
# Using the relatively clean data as compared to real original data

# Usual imports
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
# Load the data
titanic = pd.read_csv('titanic_train.csv')
```


```python
# Check the head
titanic.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PassengerId</th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>Name</th>
      <th>Sex</th>
      <th>Age</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Ticket</th>
      <th>Fare</th>
      <th>Cabin</th>
      <th>Embarked</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>Braund, Mr. Owen Harris</td>
      <td>male</td>
      <td>22.0</td>
      <td>1</td>
      <td>0</td>
      <td>A/5 21171</td>
      <td>7.2500</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>Cumings, Mrs. John Bradley (Florence Briggs Th...</td>
      <td>female</td>
      <td>38.0</td>
      <td>1</td>
      <td>0</td>
      <td>PC 17599</td>
      <td>71.2833</td>
      <td>C85</td>
      <td>C</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1</td>
      <td>3</td>
      <td>Heikkinen, Miss. Laina</td>
      <td>female</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>STON/O2. 3101282</td>
      <td>7.9250</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>1</td>
      <td>1</td>
      <td>Futrelle, Mrs. Jacques Heath (Lily May Peel)</td>
      <td>female</td>
      <td>35.0</td>
      <td>1</td>
      <td>0</td>
      <td>113803</td>
      <td>53.1000</td>
      <td>C123</td>
      <td>S</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>0</td>
      <td>3</td>
      <td>Allen, Mr. William Henry</td>
      <td>male</td>
      <td>35.0</td>
      <td>0</td>
      <td>0</td>
      <td>373450</td>
      <td>8.0500</td>
      <td>NaN</td>
      <td>S</td>
    </tr>
  </tbody>
</table>
</div>




```python
# check the info() method
titanic.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 891 entries, 0 to 890
    Data columns (total 12 columns):
    PassengerId    891 non-null int64
    Survived       891 non-null int64
    Pclass         891 non-null int64
    Name           891 non-null object
    Sex            891 non-null object
    Age            714 non-null float64
    SibSp          891 non-null int64
    Parch          891 non-null int64
    Ticket         891 non-null object
    Fare           891 non-null float64
    Cabin          204 non-null object
    Embarked       889 non-null object
    dtypes: float64(2), int64(5), object(5)
    memory usage: 83.6+ KB
    


```python
# This is a train set of titanic data so titanic is not a good name of the dataframe
titanic_train = titanic
# We find from info method that there are quit a null values
# to visualize these null values there are two methods
# Method No. 1
titanic_train.isnull().sum()
```




    PassengerId      0
    Survived         0
    Pclass           0
    Name             0
    Sex              0
    Age            177
    SibSp            0
    Parch            0
    Ticket           0
    Fare             0
    Cabin          687
    Embarked         2
    dtype: int64




```python
# Method No. 2
sns.heatmap(titanic_train.isnull())
# Use some useful attributes to make it look pretty. Check the next cell out
```




    <matplotlib.axes._subplots.AxesSubplot at 0x29e625e9c50>




![png](output_5_1.png)



```python
sns.heatmap(titanic_train.isnull(), yticklabels=False)
# check out the next cell
```




    <matplotlib.axes._subplots.AxesSubplot at 0x29e6196d8d0>




![png](output_6_1.png)



```python
sns.heatmap(titanic_train.isnull(), yticklabels=False, cbar=False)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x29e622873c8>




![png](output_7_1.png)



```python
sns.heatmap(titanic_train.isnull(), yticklabels=False, cbar=False, cmap='viridis')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x29e62932940>




![png](output_8_1.png)



```python
# Set the format for seaborn
sns.set_style('whitegrid')
```


```python
# let's make count plot for the people survived
sns.countplot(x=titanic_train['Survived'])
```




    <matplotlib.axes._subplots.AxesSubplot at 0x29e62011160>




![png](output_10_1.png)



```python
# Let's set palette in sns and run teh above command again to check the difference
sns.set_palette("GnBu_d")
sns.set_style('whitegrid')
```


```python
# BTW another way to feed the 'survived' data to the seaborn is to do it as following
sns.countplot(x='Survived',data=titanic_train)
# I do like the default version of the palette settings. How can I get it back???
```




    <matplotlib.axes._subplots.AxesSubplot at 0x29e62fde9b0>




![png](output_12_1.png)



```python
# Pass an arguments 'pastel' in the set_palette() method
sns.countplot(x='Survived',data=titanic_train)
# But the default brightness is missing
```




    <matplotlib.axes._subplots.AxesSubplot at 0x29e629c89e8>




![png](output_13_1.png)



```python
sns.set_palette('pastel', 10, .75)
sns.countplot(x='Survived',data=titanic_train)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x29e62b12588>




![png](output_14_1.png)



```python
# Moving on....
# add another dimention by passing the hue argument
sns.countplot(x='Survived',data=titanic_train, hue='Sex')
# It seems you have a bad luck while surviving from the titanic disaster if you are male
# Is above statement true? ratios are better way of addressing 
# roughly looking at the plot suggests
total_male = 480 + 105
total_female = 90 + 220
male_survival_rate = 105/total_male
female_survival_rate = 220/total_female
print('male_survival_rate: ', male_survival_rate)
print('female_survival_rate: ', female_survival_rate)
```

    male_survival_rate:  0.1794871794871795
    female_survival_rate:  0.7096774193548387
    


![png](output_15_1.png)



```python
# Let's use class as the hue
sns.countplot(x='Survived',data=titanic_train, hue='Pclass')
# Clearly if you are a female in 1st class you have the highest chances of surviving
```




    <matplotlib.axes._subplots.AxesSubplot at 0x29e63081e48>




![png](output_16_1.png)



```python
# Let's check out the age spread of the people on titanic
plt.figure(figsize=(16,7))
sns.boxplot(data=titanic_train, y='Age')
# We have 28 as a average age of a passanger
```




    <matplotlib.axes._subplots.AxesSubplot at 0x29e64709d68>




![png](output_17_1.png)



```python
# Let's say we decide to add this to each of the null value present in the 'Age' column
# we would have to build a function and then apply that function to the 'Age' column
# let's first do this with one average value like above which is 28
# First built a function

def mean_age(age):
    if pd.isnull(age):
        return 28
    else:
        return age

    
    
titanic_train['Age_with_mean'] = titanic_train['Age'].apply(mean_age)
```


```python
print(titanic_train[['Age', 'Age_with_mean']])
```

          Age  Age_with_mean
    0    22.0           22.0
    1    38.0           38.0
    2    26.0           26.0
    3    35.0           35.0
    4    35.0           35.0
    5     NaN           28.0
    6    54.0           54.0
    7     2.0            2.0
    8    27.0           27.0
    9    14.0           14.0
    10    4.0            4.0
    11   58.0           58.0
    12   20.0           20.0
    13   39.0           39.0
    14   14.0           14.0
    15   55.0           55.0
    16    2.0            2.0
    17    NaN           28.0
    18   31.0           31.0
    19    NaN           28.0
    20   35.0           35.0
    21   34.0           34.0
    22   15.0           15.0
    23   28.0           28.0
    24    8.0            8.0
    25   38.0           38.0
    26    NaN           28.0
    27   19.0           19.0
    28    NaN           28.0
    29    NaN           28.0
    ..    ...            ...
    861  21.0           21.0
    862  48.0           48.0
    863   NaN           28.0
    864  24.0           24.0
    865  42.0           42.0
    866  27.0           27.0
    867  31.0           31.0
    868   NaN           28.0
    869   4.0            4.0
    870  26.0           26.0
    871  47.0           47.0
    872  33.0           33.0
    873  47.0           47.0
    874  28.0           28.0
    875  15.0           15.0
    876  20.0           20.0
    877  19.0           19.0
    878   NaN           28.0
    879  56.0           56.0
    880  25.0           25.0
    881  33.0           33.0
    882  22.0           22.0
    883  28.0           28.0
    884  25.0           25.0
    885  39.0           39.0
    886  27.0           27.0
    887  19.0           19.0
    888   NaN           28.0
    889  26.0           26.0
    890  32.0           32.0
    
    [891 rows x 2 columns]
    


```python
# Let's make this more complicated
# Instead of taking one mean let's change it to two means one for men and one for women
plt.figure(figsize=(16,7))
sns.boxplot(data=titanic_train, x='Sex',y='Age')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x29e6465ea90>




![png](output_20_1.png)



```python
def mean_age_perSex(oranges):
    if pd.isnull(oranges[0]):
        if oranges[1]=='male':
            return 29
        elif oranges[1]=='female':
            return 27
    else:
        return oranges[0]
        
        
titanic_train['Age_with_mean_per_sex'] = titanic_train[['Age','Sex']].apply(mean_age_perSex, axis=1)
titanic_train[['Age_with_mean_per_sex','Age']].head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age_with_mean_per_sex</th>
      <th>Age</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>22.0</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>38.0</td>
      <td>38.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>26.0</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>35.0</td>
      <td>35.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>35.0</td>
      <td>35.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>29.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>6</th>
      <td>54.0</td>
      <td>54.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>27.0</td>
      <td>27.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>14.0</td>
      <td>14.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Now further add the hue=Pclass and find average for each of six categories
plt.figure(figsize=(16,7))
sns.boxplot(data=titanic_train, x='Sex',y='Age',hue='Pclass')
# Averages are Male(Pclass1 : 40; Pclass2 : 30, Pclass3: 24) and for Female(Pclass1 : 35; Pclass2 : 28, Pclass3: 22) 
```




    <matplotlib.axes._subplots.AxesSubplot at 0x29e64b71f28>




![png](output_22_1.png)



```python
# Averages are Male(Pclass1 : 40; Pclass2 : 30, Pclass3: 24) and for Female(Pclass1 : 35; Pclass2 : 28, Pclass3: 22) 
def mean_age_perSex_perPclass(oranges):
    if pd.isnull(oranges[0]):
        if oranges[1]=='male':
            if oranges[2]==1:
                return 40
            elif oranges[2]==2:
                return 30
            elif oranges[2]==3:
                return 24
        elif oranges[1]=='female':
            if oranges[2]==1:
                return 35
            elif oranges[2]==2:
                return 28
            elif oranges[2]==3:
                return 22
    else:
        return oranges[0]
        
        
titanic_train['Age_with_mean_per_sex_perPclass'] = titanic_train[['Age','Sex','Pclass']].apply(mean_age_perSex_perPclass, axis=1)
titanic_train[['Age_with_mean_per_sex_perPclass','Age']].head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age_with_mean_per_sex_perPclass</th>
      <th>Age</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>22.0</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>38.0</td>
      <td>38.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>26.0</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>35.0</td>
      <td>35.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>35.0</td>
      <td>35.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>24.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>6</th>
      <td>54.0</td>
      <td>54.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>27.0</td>
      <td>27.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>14.0</td>
      <td>14.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
import numpy as np
```


```python
# To get the values of NaNs from the 'Age' column use...
# ... np.isnan() method on the 'Age' column
np.isnan(titanic_train[['Age']]) # one set of square bracket will return series
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>False</td>
    </tr>
    <tr>
      <th>5</th>
      <td>True</td>
    </tr>
    <tr>
      <th>6</th>
      <td>False</td>
    </tr>
    <tr>
      <th>7</th>
      <td>False</td>
    </tr>
    <tr>
      <th>8</th>
      <td>False</td>
    </tr>
    <tr>
      <th>9</th>
      <td>False</td>
    </tr>
    <tr>
      <th>10</th>
      <td>False</td>
    </tr>
    <tr>
      <th>11</th>
      <td>False</td>
    </tr>
    <tr>
      <th>12</th>
      <td>False</td>
    </tr>
    <tr>
      <th>13</th>
      <td>False</td>
    </tr>
    <tr>
      <th>14</th>
      <td>False</td>
    </tr>
    <tr>
      <th>15</th>
      <td>False</td>
    </tr>
    <tr>
      <th>16</th>
      <td>False</td>
    </tr>
    <tr>
      <th>17</th>
      <td>True</td>
    </tr>
    <tr>
      <th>18</th>
      <td>False</td>
    </tr>
    <tr>
      <th>19</th>
      <td>True</td>
    </tr>
    <tr>
      <th>20</th>
      <td>False</td>
    </tr>
    <tr>
      <th>21</th>
      <td>False</td>
    </tr>
    <tr>
      <th>22</th>
      <td>False</td>
    </tr>
    <tr>
      <th>23</th>
      <td>False</td>
    </tr>
    <tr>
      <th>24</th>
      <td>False</td>
    </tr>
    <tr>
      <th>25</th>
      <td>False</td>
    </tr>
    <tr>
      <th>26</th>
      <td>True</td>
    </tr>
    <tr>
      <th>27</th>
      <td>False</td>
    </tr>
    <tr>
      <th>28</th>
      <td>True</td>
    </tr>
    <tr>
      <th>29</th>
      <td>True</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>861</th>
      <td>False</td>
    </tr>
    <tr>
      <th>862</th>
      <td>False</td>
    </tr>
    <tr>
      <th>863</th>
      <td>True</td>
    </tr>
    <tr>
      <th>864</th>
      <td>False</td>
    </tr>
    <tr>
      <th>865</th>
      <td>False</td>
    </tr>
    <tr>
      <th>866</th>
      <td>False</td>
    </tr>
    <tr>
      <th>867</th>
      <td>False</td>
    </tr>
    <tr>
      <th>868</th>
      <td>True</td>
    </tr>
    <tr>
      <th>869</th>
      <td>False</td>
    </tr>
    <tr>
      <th>870</th>
      <td>False</td>
    </tr>
    <tr>
      <th>871</th>
      <td>False</td>
    </tr>
    <tr>
      <th>872</th>
      <td>False</td>
    </tr>
    <tr>
      <th>873</th>
      <td>False</td>
    </tr>
    <tr>
      <th>874</th>
      <td>False</td>
    </tr>
    <tr>
      <th>875</th>
      <td>False</td>
    </tr>
    <tr>
      <th>876</th>
      <td>False</td>
    </tr>
    <tr>
      <th>877</th>
      <td>False</td>
    </tr>
    <tr>
      <th>878</th>
      <td>True</td>
    </tr>
    <tr>
      <th>879</th>
      <td>False</td>
    </tr>
    <tr>
      <th>880</th>
      <td>False</td>
    </tr>
    <tr>
      <th>881</th>
      <td>False</td>
    </tr>
    <tr>
      <th>882</th>
      <td>False</td>
    </tr>
    <tr>
      <th>883</th>
      <td>False</td>
    </tr>
    <tr>
      <th>884</th>
      <td>False</td>
    </tr>
    <tr>
      <th>885</th>
      <td>False</td>
    </tr>
    <tr>
      <th>886</th>
      <td>False</td>
    </tr>
    <tr>
      <th>887</th>
      <td>False</td>
    </tr>
    <tr>
      <th>888</th>
      <td>True</td>
    </tr>
    <tr>
      <th>889</th>
      <td>False</td>
    </tr>
    <tr>
      <th>890</th>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>891 rows × 1 columns</p>
</div>




```python
# Pass this series or DF in titanic_train
titanic_train[np.isnan(titanic_train[['Age']])]
# it turns out Passing a DF does not work
#WHY???? Remember passing series works
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PassengerId</th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>Name</th>
      <th>Sex</th>
      <th>Age</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Ticket</th>
      <th>Fare</th>
      <th>Cabin</th>
      <th>Embarked</th>
      <th>Age_with_mean</th>
      <th>Age_with_mean_per_sex</th>
      <th>Age_with_mean_per_sex_perPclass</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>6</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>7</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>8</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>9</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>10</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>11</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>12</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>13</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>14</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>15</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>16</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>17</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>18</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>19</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>20</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>21</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>22</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>23</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>24</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>25</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>26</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>27</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>28</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>29</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>861</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>862</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>863</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>864</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>865</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>866</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>867</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>868</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>869</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>870</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>871</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>872</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>873</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>874</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>875</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>876</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>877</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>878</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>879</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>880</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>881</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>882</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>883</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>884</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>885</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>886</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>887</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>888</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>889</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>890</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>891 rows × 15 columns</p>
</div>




```python
np.isnan(titanic_train['Age'])
```




    0      False
    1      False
    2      False
    3      False
    4      False
    5       True
    6      False
    7      False
    8      False
    9      False
    10     False
    11     False
    12     False
    13     False
    14     False
    15     False
    16     False
    17      True
    18     False
    19      True
    20     False
    21     False
    22     False
    23     False
    24     False
    25     False
    26      True
    27     False
    28      True
    29      True
           ...  
    861    False
    862    False
    863     True
    864    False
    865    False
    866    False
    867    False
    868     True
    869    False
    870    False
    871    False
    872    False
    873    False
    874    False
    875    False
    876    False
    877    False
    878     True
    879    False
    880    False
    881    False
    882    False
    883    False
    884    False
    885    False
    886    False
    887    False
    888     True
    889    False
    890    False
    Name: Age, Length: 891, dtype: bool




```python
missing_age = titanic_train[np.isnan(titanic_train['Age'])][['Age', 'Age_with_mean', 'Age_with_mean_per_sex', 'Age_with_mean_per_sex_perPclass' ]]
```


```python
# This dataframe gives missing age values based on different methods calculate
missing_age
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Age_with_mean</th>
      <th>Age_with_mean_per_sex</th>
      <th>Age_with_mean_per_sex_perPclass</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>5</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>17</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>30.0</td>
    </tr>
    <tr>
      <th>19</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>27.0</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>26</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>28</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>27.0</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>29</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>31</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>27.0</td>
      <td>35.0</td>
    </tr>
    <tr>
      <th>32</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>27.0</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>36</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>42</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>45</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>46</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>47</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>27.0</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>48</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>55</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>40.0</td>
    </tr>
    <tr>
      <th>64</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>40.0</td>
    </tr>
    <tr>
      <th>65</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>76</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>77</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>82</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>27.0</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>87</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>95</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>101</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>107</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>109</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>27.0</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>121</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>126</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>128</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>27.0</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>140</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>27.0</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>154</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>718</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>727</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>27.0</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>732</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>30.0</td>
    </tr>
    <tr>
      <th>738</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>739</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>740</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>40.0</td>
    </tr>
    <tr>
      <th>760</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>766</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>40.0</td>
    </tr>
    <tr>
      <th>768</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>773</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>776</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>778</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>783</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>790</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>792</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>27.0</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>793</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>40.0</td>
    </tr>
    <tr>
      <th>815</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>40.0</td>
    </tr>
    <tr>
      <th>825</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>826</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>828</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>832</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>837</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>839</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>40.0</td>
    </tr>
    <tr>
      <th>846</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>849</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>27.0</td>
      <td>35.0</td>
    </tr>
    <tr>
      <th>859</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>863</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>27.0</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>868</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>878</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>29.0</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>888</th>
      <td>NaN</td>
      <td>28.0</td>
      <td>27.0</td>
      <td>22.0</td>
    </tr>
  </tbody>
</table>
<p>177 rows × 4 columns</p>
</div>




```python
titanic_train.columns
```




    Index(['PassengerId', 'Survived', 'Pclass', 'Name', 'Sex', 'Age', 'SibSp',
           'Parch', 'Ticket', 'Fare', 'Cabin', 'Embarked', 'Age_with_mean',
           'Age_with_mean_per_sex', 'Age_with_mean_per_sex_perPclass'],
          dtype='object')




```python
titanic_train1 = titanic_train[['PassengerId', 'Survived', 'Pclass', 'Name', 'Sex', 'SibSp',
       'Parch', 'Ticket', 'Fare', 'Embarked', 'Age_with_mean_per_sex_perPclass']]
titanic_train1
sns.heatmap(data=titanic_train1.isnull(), yticklabels=False, cbar=False, cmap='viridis')
# The map below is like a bird-eye-view to find if there is any null values
```




    <matplotlib.axes._subplots.AxesSubplot at 0x29e65052358>




![png](output_31_1.png)



```python
titanic_train1.info()
# There are four columns below with datatype object(or string) that the machine learning algoritham cannot interpret
# Thses are
# 1. Name: This colunm can be dropped
# 2. Sex: This is a categorical column and can be converted to dummy variable column
# 3. Ticket: This column can be dropped
# 4. Embarked: This is a categorical column and can be converted to dummy variable column
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 891 entries, 0 to 890
    Data columns (total 11 columns):
    PassengerId                        891 non-null int64
    Survived                           891 non-null int64
    Pclass                             891 non-null int64
    Name                               891 non-null object
    Sex                                891 non-null object
    SibSp                              891 non-null int64
    Parch                              891 non-null int64
    Ticket                             891 non-null object
    Fare                               891 non-null float64
    Embarked                           889 non-null object
    Age_with_mean_per_sex_perPclass    891 non-null float64
    dtypes: float64(2), int64(5), object(4)
    memory usage: 76.6+ KB
    


```python
sex = pd.get_dummies(titanic_train1['Sex'])
embarked = pd.get_dummies(titanic_train1['Embarked'])
print(sex)
print(embarked)
```

         female  male
    0         0     1
    1         1     0
    2         1     0
    3         1     0
    4         0     1
    5         0     1
    6         0     1
    7         0     1
    8         1     0
    9         1     0
    10        1     0
    11        1     0
    12        0     1
    13        0     1
    14        1     0
    15        1     0
    16        0     1
    17        0     1
    18        1     0
    19        1     0
    20        0     1
    21        0     1
    22        1     0
    23        0     1
    24        1     0
    25        1     0
    26        0     1
    27        0     1
    28        1     0
    29        0     1
    ..      ...   ...
    861       0     1
    862       1     0
    863       1     0
    864       0     1
    865       1     0
    866       1     0
    867       0     1
    868       0     1
    869       0     1
    870       0     1
    871       1     0
    872       0     1
    873       0     1
    874       1     0
    875       1     0
    876       0     1
    877       0     1
    878       0     1
    879       1     0
    880       1     0
    881       0     1
    882       1     0
    883       0     1
    884       0     1
    885       1     0
    886       0     1
    887       1     0
    888       1     0
    889       0     1
    890       0     1
    
    [891 rows x 2 columns]
         C  Q  S
    0    0  0  1
    1    1  0  0
    2    0  0  1
    3    0  0  1
    4    0  0  1
    5    0  1  0
    6    0  0  1
    7    0  0  1
    8    0  0  1
    9    1  0  0
    10   0  0  1
    11   0  0  1
    12   0  0  1
    13   0  0  1
    14   0  0  1
    15   0  0  1
    16   0  1  0
    17   0  0  1
    18   0  0  1
    19   1  0  0
    20   0  0  1
    21   0  0  1
    22   0  1  0
    23   0  0  1
    24   0  0  1
    25   0  0  1
    26   1  0  0
    27   0  0  1
    28   0  1  0
    29   0  0  1
    ..  .. .. ..
    861  0  0  1
    862  0  0  1
    863  0  0  1
    864  0  0  1
    865  0  0  1
    866  1  0  0
    867  0  0  1
    868  0  0  1
    869  0  0  1
    870  0  0  1
    871  0  0  1
    872  0  0  1
    873  0  0  1
    874  1  0  0
    875  1  0  0
    876  0  0  1
    877  0  0  1
    878  0  0  1
    879  1  0  0
    880  0  0  1
    881  0  0  1
    882  0  0  1
    883  0  0  1
    884  0  0  1
    885  0  1  0
    886  0  0  1
    887  0  0  1
    888  0  0  1
    889  1  0  0
    890  0  1  0
    
    [891 rows x 3 columns]
    


```python
sex = pd.get_dummies(titanic_train1['Sex'],drop_first=True)
embarked = pd.get_dummies(titanic_train1['Embarked'],drop_first=True)
print(sex)
print(embarked)
```

         male
    0       1
    1       0
    2       0
    3       0
    4       1
    5       1
    6       1
    7       1
    8       0
    9       0
    10      0
    11      0
    12      1
    13      1
    14      0
    15      0
    16      1
    17      1
    18      0
    19      0
    20      1
    21      1
    22      0
    23      1
    24      0
    25      0
    26      1
    27      1
    28      0
    29      1
    ..    ...
    861     1
    862     0
    863     0
    864     1
    865     0
    866     0
    867     1
    868     1
    869     1
    870     1
    871     0
    872     1
    873     1
    874     0
    875     0
    876     1
    877     1
    878     1
    879     0
    880     0
    881     1
    882     0
    883     1
    884     1
    885     0
    886     1
    887     0
    888     0
    889     1
    890     1
    
    [891 rows x 1 columns]
         Q  S
    0    0  1
    1    0  0
    2    0  1
    3    0  1
    4    0  1
    5    1  0
    6    0  1
    7    0  1
    8    0  1
    9    0  0
    10   0  1
    11   0  1
    12   0  1
    13   0  1
    14   0  1
    15   0  1
    16   1  0
    17   0  1
    18   0  1
    19   0  0
    20   0  1
    21   0  1
    22   1  0
    23   0  1
    24   0  1
    25   0  1
    26   0  0
    27   0  1
    28   1  0
    29   0  1
    ..  .. ..
    861  0  1
    862  0  1
    863  0  1
    864  0  1
    865  0  1
    866  0  0
    867  0  1
    868  0  1
    869  0  1
    870  0  1
    871  0  1
    872  0  1
    873  0  1
    874  0  0
    875  0  0
    876  0  1
    877  0  1
    878  0  1
    879  0  0
    880  0  1
    881  0  1
    882  0  1
    883  0  1
    884  0  1
    885  1  0
    886  0  1
    887  0  1
    888  0  1
    889  0  0
    890  1  0
    
    [891 rows x 2 columns]
    


```python
sex_embarked = pd.concat([sex, embarked], axis=1)
sex_embarked
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>male</th>
      <th>Q</th>
      <th>S</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>12</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>13</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>14</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>16</th>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>17</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>18</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>19</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>20</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>21</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>22</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>23</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>26</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>27</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>28</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>861</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>862</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>863</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>864</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>865</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>866</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>867</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>868</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>869</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>870</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>871</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>872</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>873</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>874</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>875</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>876</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>877</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>878</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>879</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>880</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>881</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>882</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>883</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>884</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>885</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>886</th>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>887</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>888</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>889</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>890</th>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>891 rows × 3 columns</p>
</div>




```python
titanic_train1.columns
```




    Index(['PassengerId', 'Survived', 'Pclass', 'Name', 'Sex', 'SibSp', 'Parch',
           'Ticket', 'Fare', 'Embarked', 'Age_with_mean_per_sex_perPclass'],
          dtype='object')




```python
# we drop 'Name', 'Sex', 'Ticket', 'Embarked' columns or make a new DF without these coulumns
```


```python
train = titanic_train1[['PassengerId', 'Survived', 'Pclass', 'SibSp', 'Parch', 'Fare', 'Age_with_mean_per_sex_perPclass']]
```


```python
train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PassengerId</th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Fare</th>
      <th>Age_with_mean_per_sex_perPclass</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>7.2500</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>71.2833</td>
      <td>38.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>7.9250</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>53.1000</td>
      <td>35.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>8.0500</td>
      <td>35.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Now concatenate dummy 'sex' and dummy 'embarked' DFs with train
train = pd.concat([train, sex_embarked],axis=1)
train
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PassengerId</th>
      <th>Survived</th>
      <th>Pclass</th>
      <th>SibSp</th>
      <th>Parch</th>
      <th>Fare</th>
      <th>Age_with_mean_per_sex_perPclass</th>
      <th>male</th>
      <th>Q</th>
      <th>S</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>7.2500</td>
      <td>22.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>71.2833</td>
      <td>38.0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>7.9250</td>
      <td>26.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>53.1000</td>
      <td>35.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>8.0500</td>
      <td>35.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>8.4583</td>
      <td>24.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>51.8625</td>
      <td>54.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>0</td>
      <td>3</td>
      <td>3</td>
      <td>1</td>
      <td>21.0750</td>
      <td>2.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>2</td>
      <td>11.1333</td>
      <td>27.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>30.0708</td>
      <td>14.0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>11</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>16.7000</td>
      <td>4.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>11</th>
      <td>12</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>26.5500</td>
      <td>58.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>12</th>
      <td>13</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>8.0500</td>
      <td>20.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>13</th>
      <td>14</td>
      <td>0</td>
      <td>3</td>
      <td>1</td>
      <td>5</td>
      <td>31.2750</td>
      <td>39.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>14</th>
      <td>15</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>7.8542</td>
      <td>14.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>15</th>
      <td>16</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>16.0000</td>
      <td>55.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>16</th>
      <td>17</td>
      <td>0</td>
      <td>3</td>
      <td>4</td>
      <td>1</td>
      <td>29.1250</td>
      <td>2.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>17</th>
      <td>18</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>13.0000</td>
      <td>30.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>18</th>
      <td>19</td>
      <td>0</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>18.0000</td>
      <td>31.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>19</th>
      <td>20</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>7.2250</td>
      <td>22.0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>20</th>
      <td>21</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>26.0000</td>
      <td>35.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>21</th>
      <td>22</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>13.0000</td>
      <td>34.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>22</th>
      <td>23</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>8.0292</td>
      <td>15.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>23</th>
      <td>24</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>35.5000</td>
      <td>28.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>24</th>
      <td>25</td>
      <td>0</td>
      <td>3</td>
      <td>3</td>
      <td>1</td>
      <td>21.0750</td>
      <td>8.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>25</th>
      <td>26</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>5</td>
      <td>31.3875</td>
      <td>38.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>26</th>
      <td>27</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>7.2250</td>
      <td>24.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>27</th>
      <td>28</td>
      <td>0</td>
      <td>1</td>
      <td>3</td>
      <td>2</td>
      <td>263.0000</td>
      <td>19.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>28</th>
      <td>29</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>7.8792</td>
      <td>22.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29</th>
      <td>30</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>7.8958</td>
      <td>24.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>861</th>
      <td>862</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>11.5000</td>
      <td>21.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>862</th>
      <td>863</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>25.9292</td>
      <td>48.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>863</th>
      <td>864</td>
      <td>0</td>
      <td>3</td>
      <td>8</td>
      <td>2</td>
      <td>69.5500</td>
      <td>22.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>864</th>
      <td>865</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>13.0000</td>
      <td>24.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>865</th>
      <td>866</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>13.0000</td>
      <td>42.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>866</th>
      <td>867</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>13.8583</td>
      <td>27.0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>867</th>
      <td>868</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>50.4958</td>
      <td>31.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>868</th>
      <td>869</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>9.5000</td>
      <td>24.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>869</th>
      <td>870</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
      <td>11.1333</td>
      <td>4.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>870</th>
      <td>871</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>7.8958</td>
      <td>26.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>871</th>
      <td>872</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>52.5542</td>
      <td>47.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>872</th>
      <td>873</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>5.0000</td>
      <td>33.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>873</th>
      <td>874</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>9.0000</td>
      <td>47.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>874</th>
      <td>875</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>0</td>
      <td>24.0000</td>
      <td>28.0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>875</th>
      <td>876</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>7.2250</td>
      <td>15.0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>876</th>
      <td>877</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>9.8458</td>
      <td>20.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>877</th>
      <td>878</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>7.8958</td>
      <td>19.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>878</th>
      <td>879</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>7.8958</td>
      <td>24.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>879</th>
      <td>880</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>83.1583</td>
      <td>56.0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>880</th>
      <td>881</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>1</td>
      <td>26.0000</td>
      <td>25.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>881</th>
      <td>882</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>7.8958</td>
      <td>33.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>882</th>
      <td>883</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>10.5167</td>
      <td>22.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>883</th>
      <td>884</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>10.5000</td>
      <td>28.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>884</th>
      <td>885</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>7.0500</td>
      <td>25.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>885</th>
      <td>886</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>5</td>
      <td>29.1250</td>
      <td>39.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>886</th>
      <td>887</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>13.0000</td>
      <td>27.0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>887</th>
      <td>888</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>30.0000</td>
      <td>19.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>888</th>
      <td>889</td>
      <td>0</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
      <td>23.4500</td>
      <td>22.0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>889</th>
      <td>890</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>30.0000</td>
      <td>26.0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>890</th>
      <td>891</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>7.7500</td>
      <td>32.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>891 rows × 10 columns</p>
</div>



## Building a logistic regression model

### Train Test Split


```python
from sklearn.model_selection import train_test_split
```




    <function sklearn.model_selection._split.train_test_split(*arrays, **options)>




```python
X_train, X_test, y_train, y_test = train_test_split(train.drop('Survived', axis=1),
                                                    train['Survived'], test_size=0.3, 
                                                    random_state=101)
```

### Training and Predicting


```python
from sklearn.linear_model import LogisticRegression
lr = LogisticRegression()
```


```python
lr.fit(X_train, y_train)
```

    C:\Users\vtaor\Anaconda3\lib\site-packages\sklearn\linear_model\logistic.py:432: FutureWarning: Default solver will be changed to 'lbfgs' in 0.22. Specify a solver to silence this warning.
      FutureWarning)
    




    LogisticRegression(C=1.0, class_weight=None, dual=False, fit_intercept=True,
                       intercept_scaling=1, l1_ratio=None, max_iter=100,
                       multi_class='warn', n_jobs=None, penalty='l2',
                       random_state=None, solver='warn', tol=0.0001, verbose=0,
                       warm_start=False)




```python
predictions = lr.predict(X_test)
```

### Evaluation


```python
# We can check precision, recall and f1-score using classification report
from sklearn.metrics import classification_report
```


```python
print(classification_report(y_test, predictions))
```

                  precision    recall  f1-score   support
    
               0       0.77      0.88      0.82       154
               1       0.79      0.64      0.71       114
    
        accuracy                           0.78       268
       macro avg       0.78      0.76      0.76       268
    weighted avg       0.78      0.78      0.77       268
    
    
